import { defineConfig } from 'wxt';

// See https://wxt.dev/api/config.html
export default defineConfig({
  modules: ['@wxt-dev/module-react'],
  manifest: {
    name: 'ProxyOrb - Free Web Proxy Extension',
    description: 'Free Web Site Proxy & Online Proxy Browser for secure, anonymous access to any blocked website.',
    version: '1.0.0',
    permissions: [
      'contextMenus',
      'tabs',
      'activeTab'
    ],
    host_permissions: [
      '<all_urls>'
    ],
    action: {
      default_title: 'ProxyOrb - Open Proxy Browser'
    },
    icons: {
      16: '/icon/16.png',
      32: '/icon/32.png',
      48: '/icon/48.png',
      96: '/icon/96.png',
      128: '/icon/128.png'
    },
    homepage_url: 'https://proxyorb.com'
  }
});
