#!/bin/bash

# 🔧 ProxyOrb Extension Git Commit Script
# 简单的Git提交工具，专门用于git-release目录

set -e

# 检查git-release目录是否存在
if [ ! -d "git-release" ]; then
    echo "❌ Error: git-release directory not found!"
    echo "Please run './release.sh' first to generate the git-release directory."
    exit 1
fi

echo "🔧 Setting up Git for ProxyOrb Extension..."

# 获取版本号
VERSION=$(grep '"version":' package.json | sed 's/.*"version": "\(.*\)".*/\1/')
echo "📦 Version: $VERSION"

# 进入git-release目录
cd git-release

# 检查是否已经是Git仓库
if [ -d ".git" ]; then
    echo "⚠️  Git repository already exists in git-release directory."
    echo "🔄 Adding new files..."
else
    echo "📁 Initializing Git repository in git-release directory..."
    git init
    echo "✅ Git repository initialized."
fi

# 添加所有文件
echo "📋 Adding all files to Git..."
git add .

# 检查是否有文件被添加
if [ -n "$(git diff --cached --name-only)" ]; then
    echo "📦 Files added to staging:"
    git diff --cached --name-only | sed 's/^/  ✅ /'
    
    # 提交文件
    echo "💾 Creating commit..."
    git commit -m "🚀 Release v${VERSION} - ProxyOrb Browser Extension

📦 Multi-browser support:
- ✅ Chrome Extension (Manifest V3)
- ✅ Firefox Add-on (Manifest V2)  
- ✅ Safari Extension (Manifest V2)
- ✅ Microsoft Edge Extension (Manifest V3)

✨ Features:
- 🚀 One-click proxy for current page
- 🖱️ Context menu integration
- 📱 Modern popup UI with installation guide
- 🔒 Privacy-focused (zero logs)
- 🆓 Completely free

🔗 ProxyOrb integration: https://proxyorb.com/?q={url}"

    echo "✅ Commit created successfully!"
else
    echo "⚠️  No new files to commit."
fi

# 返回主目录
cd ..

# 显示Git状态
echo ""
echo "📊 Git Status in git-release/:"
cd git-release
git status --short
cd ..
echo ""

# 显示下一步操作
echo "🔄 Next steps:"
echo "  1. Create a GitHub repository:"
echo "     https://github.com/new"
echo ""
echo "  2. Push to GitHub:"
echo "     cd git-release"
echo "     git remote add origin https://github.com/yourusername/proxyorb-extension.git"
echo "     git branch -M main"
echo "     git push -u origin main"
echo ""
echo "  3. Create GitHub Release:"
echo "     - Go to your repository on GitHub"
echo "     - Click 'Releases' → 'Create a new release'"
echo "     - Tag version: v${VERSION}"
echo "     - Upload zip files as assets"
echo ""
echo "🎉 Git commit completed! Ready for GitHub!" 