#!/bin/bash

# 🚀 ProxyOrb Extension Release Script
# 自动化准备发布文件

set -e

echo "🚀 Starting ProxyOrb Extension Release Process..."

# 获取版本号
VERSION=$(grep '"version":' package.json | sed 's/.*"version": "\(.*\)".*/\1/')
echo "📦 Version: $VERSION"

# 1. 清理旧的构建文件
echo "🧹 Cleaning old build files..."
rm -rf .output/*.zip
rm -rf releases/
rm -rf git-release/

# 2. 构建所有浏览器版本
echo "🔨 Building for all browsers..."
echo "  - Building Chrome..."
pnpm build > /dev/null 2>&1
echo "  - Building Firefox..."
pnpm build:firefox > /dev/null 2>&1
echo "  - Building Safari..."
pnpm wxt build -b safari > /dev/null 2>&1
echo "  - Building Edge..."
pnpm wxt build -b edge > /dev/null 2>&1

# 3. 创建压缩包
echo "📦 Creating zip packages..."
pnpm zip > /dev/null 2>&1
pnpm zip:firefox > /dev/null 2>&1
pnpm wxt zip -b safari > /dev/null 2>&1
pnpm wxt zip -b edge > /dev/null 2>&1

# 4. 创建发布目录结构
echo "📁 Creating release directory structure..."
mkdir -p releases/v${VERSION}
mkdir -p releases/latest

# 5. 复制扩展包到发布目录
echo "📋 Copying extension packages..."
cp .output/*.zip releases/v${VERSION}/

# 6. 创建latest版本（去掉版本号）
echo "🔗 Creating latest version links..."
cd releases/latest
cp ../v${VERSION}/proxyorb-extension-${VERSION}-chrome.zip proxyorb-extension-chrome.zip
cp ../v${VERSION}/proxyorb-extension-${VERSION}-firefox.zip proxyorb-extension-firefox.zip
cp ../v${VERSION}/proxyorb-extension-${VERSION}-safari.zip proxyorb-extension-safari.zip
cp ../v${VERSION}/proxyorb-extension-${VERSION}-edge.zip proxyorb-extension-edge.zip
cp ../v${VERSION}/proxyorb-extension-${VERSION}-sources.zip proxyorb-extension-sources.zip
cd ../..

# 7. 创建专门的Git提交目录
echo "📁 Creating Git release directory..."
mkdir -p git-release
mkdir -p git-release/releases/v${VERSION}
mkdir -p git-release/releases/latest
mkdir -p git-release/docs

# 8. 复制需要提交到Git的文件
echo "📋 Preparing files for Git..."
cp README.md git-release/
cp releases/v${VERSION}/*.zip git-release/releases/v${VERSION}/
cp releases/latest/*.zip git-release/releases/latest/

# 9. 更新Git版本的README.md添加下载链接
echo "📝 Updating README.md for Git..."
if ! grep -q "## 📦 Download" git-release/README.md; then
cat >> git-release/README.md << 'EOF'

## 📦 Download

### Browser Extension Stores
- 🌐 [Chrome Web Store](https://chrome.google.com/webstore) - Coming Soon
- 🦊 [Firefox Add-ons](https://addons.mozilla.org) - Coming Soon  
- 🔷 [Microsoft Edge Add-ons](https://microsoftedge.microsoft.com/addons) - Coming Soon
- 🍎 [Safari Extensions](https://developer.apple.com/safari/extensions/) - Coming Soon

### Version History
- [All Releases](releases/)
EOF
fi

# 10. 使用sed更新安装指南中的下载链接为GitHub raw链接
echo "🔗 Updating installation download links..."
sed -i.bak 's|Download the latest Chrome extension from \[Direct Download\](#direct-download)|Download: [proxyorb-extension-chrome.zip](https://github.com/proxyorb/proxyorb-extension/raw/master/releases/latest/proxyorb-extension-chrome.zip)|g' git-release/README.md
sed -i.bak 's|Download the Safari extension from \[Direct Download\](#direct-download)|Download: [proxyorb-extension-safari.zip](https://github.com/proxyorb/proxyorb-extension/raw/master/releases/latest/proxyorb-extension-safari.zip)|g' git-release/README.md
sed -i.bak 's|Download latest version from \[Direct Download\](#direct-download)|Download latest version from the download links above|g' git-release/README.md
rm -f git-release/README.md.bak

# 11. 创建changelog
echo "📋 Creating changelog..."
cat > git-release/docs/changelog.md << EOF
# 📋 Changelog

## [${VERSION}] - $(date +%Y-%m-%d)

### ✨ Features
- 🚀 One-click proxy for current page
- 🖱️ Context menu integration for pages and links
- 🌐 Multi-browser support (Chrome, Firefox, Safari, Edge)
- 📱 Modern and beautiful popup UI
- 🔗 Privacy policy and terms of service integration

### 🎯 Browser Support
- ✅ Chrome (Manifest V3)
- ✅ Firefox (Manifest V2)
- ✅ Safari (Manifest V2)
- ✅ Microsoft Edge (Manifest V3)

### 📦 Package Sizes
- Chrome: ~107.83 KB
- Firefox: ~107.82 KB (+ 104.91 KB sources)
- Safari: ~107.82 KB
- Edge: ~107.83 KB

### 🔧 Technical Details
- Built with WXT Framework + React + TypeScript
- ProxyOrb integration: https://proxyorb.com/?q={url}
- Zero-logs privacy policy
- No registration required
EOF

# 12. 创建.gitignore文件
echo "📝 Creating .gitignore for Git release..."
cat > git-release/.gitignore << 'EOF'
# This repository only contains release files and documentation
# Development files are not included

# OS files
.DS_Store
Thumbs.db

# Temporary files
*.tmp
*.temp
EOF

# 13. 显示生成的文件信息
echo ""
echo "✅ Release preparation completed!"
echo ""
echo "📦 Browser Store Files (releases/):"
echo "  📁 releases/v${VERSION}/"
for file in releases/v${VERSION}/*.zip; do
    if [ -f "$file" ]; then
        size=$(ls -lh "$file" | awk '{print $5}')
        basename_file=$(basename "$file")
        echo "    📦 $basename_file ($size)"
    fi
done
echo ""
echo "🔗 Direct Download Files (releases/latest/):"
for file in releases/latest/*.zip; do
    if [ -f "$file" ]; then
        size=$(ls -lh "$file" | awk '{print $5}')
        basename_file=$(basename "$file")
        echo "    🔗 $basename_file ($size)"
    fi
done
echo ""
echo "📁 Git Release Directory (git-release/):"
echo "    📖 README.md (with installation guide)"
echo "    📄 docs/changelog.md"
echo "    🗂️ releases/v${VERSION}/ (5 files)"
echo "    🗂️ releases/latest/ (5 files)"
echo "    📝 .gitignore"
echo ""
echo "🎯 Simple Git Workflow:"
echo "  1. cd git-release"
echo "  2. git init"
echo "  3. git add ."
echo "  4. git commit -m '🚀 Release v${VERSION}'"
echo "  5. git remote add origin <your-repo-url>"
echo "  6. git push -u origin main"
echo ""
echo "🌐 Upload to browser stores:"
echo "  - Chrome Web Store: $(pwd)/releases/v${VERSION}/proxyorb-extension-${VERSION}-chrome.zip"
echo "  - Firefox Add-ons: $(pwd)/releases/v${VERSION}/proxyorb-extension-${VERSION}-firefox.zip"
echo "  - Safari Extensions: $(pwd)/releases/v${VERSION}/proxyorb-extension-${VERSION}-safari.zip"
echo "  - Microsoft Edge: $(pwd)/releases/v${VERSION}/proxyorb-extension-${VERSION}-edge.zip"
echo ""
echo "🎉 Ready for release!" 