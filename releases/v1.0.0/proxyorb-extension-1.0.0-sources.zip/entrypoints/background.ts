export default defineBackground(() => {
  console.log('ProxyOrb Background Service Started!', { id: browser.runtime.id });

  // 创建右键菜单
  browser.runtime.onInstalled.addListener(() => {
    // 创建页面右键菜单
    browser.contextMenus.create({
      id: 'proxy-current-page',
      title: 'Proxy this page with ProxyOrb',
      contexts: ['page'],
    });

    // 创建链接右键菜单
    browser.contextMenus.create({
      id: 'proxy-link',
      title: 'Proxy this link with ProxyOrb',
      contexts: ['link'],
    });

    // 创建选中文本右键菜单（如果是URL）
    browser.contextMenus.create({
      id: 'proxy-selection',
      title: 'Proxy selected content with ProxyOrb',
      contexts: ['selection'],
    });

    console.log('ProxyOrb context menus created');
  });

  // 处理右键菜单点击事件
  browser.contextMenus.onClicked.addListener(async (info, tab) => {
    let targetUrl = '';

    switch (info.menuItemId) {
      case 'proxy-current-page':
        // 代理当前页面
        if (tab?.url) {
          targetUrl = tab.url;
        }
        break;

      case 'proxy-link':
        // 代理选中的链接
        if (info.linkUrl) {
          targetUrl = info.linkUrl;
        }
        break;

      case 'proxy-selection':
        // 代理选中的文本（如果是URL）
        if (info.selectionText) {
          const selectedText = info.selectionText.trim();
          // 简单判断选中文本是否为URL
          if (isValidUrl(selectedText)) {
            targetUrl = selectedText;
          } else {
            // 如果不是URL，可以搜索该文本
            targetUrl = `https://www.google.com/search?q=${encodeURIComponent(selectedText)}`;
          }
        }
        break;
    }

    if (targetUrl) {
      // 打开ProxyOrb代理页面
      const proxyUrl = `https://proxyorb.com/?q=${encodeURIComponent(targetUrl)}`;
      
      try {
        await browser.tabs.create({
          url: proxyUrl,
          index: (tab?.index || 0) + 1 // 在当前标签页后面打开
        });
        console.log(`ProxyOrb: Proxying URL - ${targetUrl}`);
      } catch (error) {
        console.error('Error creating proxy tab:', error);
      }
    }
  });

  // 处理来自popup或content script的消息
  browser.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.type === 'PROXY_URL') {
      const { url } = message;
      if (url) {
        const proxyUrl = `https://proxyorb.com/?q=${encodeURIComponent(url)}`;
        try {
          await browser.tabs.create({ url: proxyUrl });
          sendResponse({ success: true });
        } catch (error) {
          console.error('Error proxying URL:', error);
          sendResponse({ success: false, error: error instanceof Error ? error.message : 'Unknown error' });
        }
      }
    }
  });
});

// 工具函数：验证URL格式
function isValidUrl(string: string): boolean {
  try {
    // 如果没有协议，尝试添加http://
    if (!string.includes('://')) {
      string = 'http://' + string;
    }
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}
