import { useState } from 'react';
import './App.css';

function App() {
  const [loading, setLoading] = useState(false);

  const handleProxyCurrentPage = async () => {
    setLoading(true);
    try {
      // 获取当前活动标签页
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      if (tab?.url) {
        // 跳转到ProxyOrb代理页面
        const proxyUrl = `https://proxyorb.com/?q=${encodeURIComponent(tab.url)}`;
        await browser.tabs.create({ url: proxyUrl });
        window.close(); // 关闭popup
      }
    } catch (error) {
      console.error('Error proxying current page:', error);
    } finally {
      setLoading(false);
    }
  };

  const openLink = (url: string) => {
    browser.tabs.create({ url });
    window.close();
  };

  return (
    <div className="proxyorb-popup">
      <div className="header">
        <h1>ProxyOrb</h1>
        <p>Free Web Site Proxy & Online Proxy Browser</p>
      </div>
      
      <div className="main-action">
        <button 
          className="proxy-button"
          onClick={handleProxyCurrentPage}
          disabled={loading}
        >
          {loading ? 'Loading...' : 'Proxy Current Page'}
        </button>
      </div>

      <div className="description">
        <p>
          Use ProxyOrb free proxy service to securely and anonymously access blocked websites.
          No registration required, ready to use!
        </p>
      </div>

      <div className="links">
        <a 
          href="#"
          onClick={(e) => {
            e.preventDefault();
            openLink('https://proxyorb.com/privacy-policy');
          }}
        >
          Privacy Policy
        </a>
        <span className="separator">|</span>
        <a 
          href="#"
          onClick={(e) => {
            e.preventDefault();
            openLink('https://proxyorb.com/terms-of-service');
          }}
        >
          Terms of Service
        </a>
      </div>

      <div className="footer">
        <p>
          <a href="https://proxyorb.com" target="_blank" rel="noopener noreferrer">
            proxyorb.com
          </a>
        </p>
      </div>
    </div>
  );
}

export default App;
