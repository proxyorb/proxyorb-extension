# 🚀 ProxyOrb Extension Release Guide

## 📦 已生成的发布文件

### 浏览器扩展包
- `proxyorb-extension-1.0.0-chrome.zip` - Chrome Web Store (107.83 KB)
- `proxyorb-extension-1.0.0-firefox.zip` - Firefox Add-ons (107.82 KB)
- `proxyorb-extension-1.0.0-safari.zip` - Safari Extension (107.82 KB)
- `proxyorb-extension-1.0.0-edge.zip` - Microsoft Edge Add-ons (107.83 KB)
- `proxyorb-extension-1.0.0-sources.zip` - 源代码包 (Firefox商店需要，104.91 KB)

### 文档文件
- `README.md` - 项目说明文档（包含安装指南）

## 🗂️ Git仓库发布结构

建议的Git仓库结构：
```
proxyorb-extension/
├── README.md                               # 项目说明+安装指南
├── releases/                               # 发布文件夹
│   ├── v1.0.0/                            # 版本文件夹
│   │   ├── proxyorb-extension-1.0.0-chrome.zip
│   │   ├── proxyorb-extension-1.0.0-firefox.zip
│   │   ├── proxyorb-extension-1.0.0-safari.zip
│   │   ├── proxyorb-extension-1.0.0-edge.zip
│   │   └── proxyorb-extension-1.0.0-sources.zip
│   └── latest/                            # 最新版本软链接或复制
│       ├── proxyorb-extension-chrome.zip
│       ├── proxyorb-extension-firefox.zip
│       ├── proxyorb-extension-safari.zip
│       ├── proxyorb-extension-edge.zip
│       └── proxyorb-extension-sources.zip
├── docs/                                   # 文档目录
│   ├── privacy-policy.md                  # 隐私政策
│   ├── terms-of-service.md               # 服务条款
│   └── changelog.md                       # 更新日志
└── assets/                                # 资源文件
    ├── screenshots/                       # 截图
    ├── icons/                            # 图标
    └── demo.gif                          # 演示动图
```

## 📋 发布步骤

### 1. 创建Git仓库
```bash
# 初始化仓库
git init
git add README.md
git commit -m "📚 Initial documentation"

# 添加远程仓库
git remote add origin https://github.com/proxyorb/browser-extension.git
git branch -M main
```

### 2. 使用自动化脚本
```bash
# 运行发布脚本
./release.sh

# 运行Git提交脚本
./git-commit.sh
```

### 3. 推送到GitHub
```bash
cd git-release
git remote add origin https://github.com/yourusername/proxyorb-extension.git
git branch -M main
git push -u origin main
```

### 4. 创建GitHub Release
在GitHub仓库中：
1. 点击 "Releases" → "Create a new release"
2. Tag version: `v1.0.0`
3. Release title: `ProxyOrb Extension v1.0.0`
4. 描述中添加功能说明
5. 上传所有扩展包作为附件

## 🌐 商店发布链接

### Chrome Web Store
- 开发者控制台: https://chrome.google.com/webstore/devconsole
- 上传: `proxyorb-extension-1.0.0-chrome.zip`

### Firefox Add-ons
- 开发者中心: https://addons.mozilla.org/developers/
- 上传: `proxyorb-extension-1.0.0-firefox.zip`
- 源代码: `proxyorb-extension-1.0.0-sources.zip`

### Microsoft Edge Add-ons
- 合作伙伴中心: https://partner.microsoft.com/dashboard/microsoftedge
- 上传: `proxyorb-extension-1.0.0-edge.zip`

### Safari Extension
- Safari开发者计划: https://developer.apple.com/safari/extensions/
- 上传: `proxyorb-extension-1.0.0-safari.zip`

## 📝 README.md 更新建议

在README.md中添加下载链接：

```markdown
## 📦 Download

### Browser Extension Stores
- 🌐 [Chrome Web Store](https://chrome.google.com/webstore) - Coming Soon
- 🦊 [Firefox Add-ons](https://addons.mozilla.org) - Coming Soon  
- 🔷 [Microsoft Edge Add-ons](https://microsoftedge.microsoft.com/addons) - Coming Soon
- 🍎 [Safari Extensions](https://developer.apple.com/safari/extensions/) - Coming Soon

### Direct Download
- [Chrome Extension](releases/latest/proxyorb-extension-chrome.zip)
- [Firefox Extension](releases/latest/proxyorb-extension-firefox.zip)
- [Edge Extension](releases/latest/proxyorb-extension-edge.zip)
- [Safari Extension](releases/latest/proxyorb-extension-safari.zip)
```

## 🔄 版本更新流程

每次发布新版本时：

1. 更新版本号在 `package.json` 和 `wxt.config.ts`
2. 构建所有浏览器版本：
   ```bash
   pnpm build && pnpm build:firefox && pnpm wxt build -b safari && pnpm wxt build -b edge
   pnpm zip && pnpm zip:firefox && pnpm wxt zip -b safari && pnpm wxt zip -b edge
   ```
3. 创建新版本文件夹: `releases/v1.x.x/`
4. 更新 `releases/latest/` 中的文件
5. 更新 `